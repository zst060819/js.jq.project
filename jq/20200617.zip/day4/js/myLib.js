(function (w) {
    w.$ = function () {
        alert('我是myLib')
    }
})(window)

